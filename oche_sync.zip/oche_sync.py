#!/usr/bin/env python3
"""
oche_sync.py
============
Pulls your n01darts.com (nakka) match history and produces the two files
OCHE (oche.pages.dev) needs to show your stats -- all in one script, with
as little typing as possible.

WHAT THIS DOES
--------------
1. First run: asks for two things -- your n01darts gid and your display
   name -- then pulls your ENTIRE match history from n01's server.
2. Every run after that: remembers what you told it (saved in
   config.json next to this script's data folder) and only pulls
   matches you've played since last time. No more prompts, ever, unless
   you ask it to forget (--reconfigure).
3. Always finishes by producing two ready-to-upload files in the
   "oche_data" folder -- just go to oche.pages.dev, click "Analyze your
   own data", and add both.

WHERE YOUR DATA LIVES
----------------------
Everything goes in a folder called "Oche" in your Documents folder
(falls back to your home folder if you don't have a Documents folder):

  Windows: C:\\Users\\<you>\\Documents\\Oche\\
  Mac:     /Users/<you>/Documents/Oche/
  Linux:   ~/Documents/Oche/ (or ~/Oche/ if you have no Documents folder)

Inside that:
  config.json          -- your saved gid + name (so you're never asked again)
  raw_pull\\             -- the script's own working data, never needs
                             your attention (matches.csv, legs.csv,
                             turns.csv, and a raw_cache\\ folder with a
                             saved copy of every match ever fetched, so
                             re-runs never re-ask n01's server for
                             something they already have)
  oche_data\\            -- data.csv and legs.csv -- THESE are the two
                             files you upload to OCHE

USAGE
-----
Just run it -- no arguments needed:

    python3 oche_sync.py

First time, it'll ask for your gid and name. Every time after that, it
just quietly updates and tells you when it's done.

FINDING YOUR GID
----------------
1. Go to https://n01darts.com (no separate login button -- you'll
   authenticate as part of step 2).
2. Create an online game -- you'll be prompted to sign in via Google,
   Facebook, or X. Check "require a secret to join" so nobody joins and
   starts a match on you.
3. In the list of available online matches, click your own name.
4. This opens your stats -- click History.
5. Look at the URL in your address bar -- copy the number after `gid=`.

ADVANCED OPTIONS (not needed for normal use)
---------------------------------------------
  --out-dir PATH     Use a different folder instead of Documents/Oche
  --gid GID          Skip the gid prompt/saved config, use this instead
  --my-name NAME     Skip the name prompt/saved config, use this instead
  --reconfigure      Forget the saved gid/name and ask again
  --full             Force a complete re-pull, ignoring/overwriting
                      everything already saved (normally never needed --
                      re-runs already auto-update incrementally)
  --from-cache       Reprocess your whole history from the local cache
                      with ZERO requests to n01's server (useful if this
                      script gets updated later with improved stats math)
  --summary-only     Only pull match-level summaries, skip leg/turn
                      detail (faster, but you lose First9/Checkout%/etc.)
"""

import argparse
import csv
import json
import re
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path


# =====================================================================
# Shared helpers
# =====================================================================

def normalize_name(name):
    """
    People change their n01 display name over time (adding/dropping a
    nickname), which otherwise fractures stats across multiple distinct
    strings for the same person, e.g.:
      'Jamie "Longshot" Fisher', 'Jamie "Big Bear" Fisher',
      'Jamie Fisher'  -->  all become 'Jamie Fisher'
    """
    if not name:
        return name
    cleaned = _NICKNAME_RE.sub(" ", name)
    return re.sub(r"\s+", " ", cleaned).strip()


_NICKNAME_RE = re.compile(r'\s*["\u201c\u2018][^"\u201c\u201d\u2018\u2019]*["\u201d\u2019]\s*')

BOGEY_SCORES = {1, 159, 162, 163, 165, 166, 168, 169}

# CHECKOUT_FINISH_THRESHOLD: for a non-checkout turn to get any credit at
# all (outside the <=40 tier below), it must leave the player at or below
# this remaining score afterward -- calibrated against 216 real matches,
# 49 gave the best balance (48.1% of matches exact, ~70% within 10%,
# totals landing at 98.3% of nakka's combined figure across the dataset).
CHECKOUT_FINISH_THRESHOLD = 49


def turn_checkout_credit(before, after):
    """
    Estimated number of darts (0-3) thrown at a double during a single
    non-checkout turn, given the remaining score before and after that
    turn. Formalizes Craig's own turn-by-turn reasoning about how many
    darts of a given turn could plausibly have been at a double, since
    n01 never exposes real per-dart data -- only these turn-level totals.

    - Starting <=40 (and not a bogey/impossible position): already on a
      genuine 1-dart double-out, so the whole turn plausibly could have
      been thrown at it. Even values get full credit (3); odd values
      need one setup dart first, so 2.
    - Starting <=110: only counts if the turn also left the player at 49
      or below afterward -- i.e. they clearly closed in on a finish, not
      just scored normally. If so, credit 2.
    - Starting <=170 (excluding bogey scores): same finishing
      requirement, but this far out only earns 1 dart of credit.
    - Otherwise: 0.

    Still an ESTIMATE, not nakka's real (undisclosed) calculation.
    """
    if before == 1:
        return 0
    if before <= 40:
        return 3 if before % 2 == 0 else 2
    if before <= 110:
        return 2 if after <= CHECKOUT_FINISH_THRESHOLD else 0
    if before <= 170 and before not in BOGEY_SCORES:
        return 1 if after <= CHECKOUT_FINISH_THRESHOLD else 0
    return 0


BASE = "https://tk2-228-23746.vs.sakura.ne.jp/n01/online/n01_history.php"
ORIGIN = "https://n01darts.com"
USER_AGENT = "Mozilla/5.0 (oche-sync/1.0; personal data export)"
PAGE_SIZE = 30

MID_KEYS = ["mid", "matchId", "match_id", "id"]

# Fallback if the name prompt is skipped entirely.
MY_NAME_DEFAULT = ""


def format_date(unix_ts):
    if not unix_ts:
        return ""
    try:
        return datetime.fromtimestamp(int(unix_ts)).strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, OSError, OverflowError):
        return ""


def _request(cmd, params=None, method="POST"):
    qs = f"cmd={cmd}"
    if params:
        for k, v in params.items():
            qs += f"&{k}={v}"
    url = f"{BASE}?{qs}"
    headers = {"User-Agent": USER_AGENT, "Accept": "*/*", "Origin": ORIGIN, "Referer": ORIGIN + "/"}
    data = b"" if method == "POST" else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            body = resp.read()
    except urllib.error.HTTPError as e:
        print(f"  ! HTTP {e.code} on {cmd}: {e.reason}", file=sys.stderr)
        return None
    except urllib.error.URLError as e:
        print(f"  ! Network error on {cmd}: {e.reason}", file=sys.stderr)
        return None
    try:
        return json.loads(body)
    except json.JSONDecodeError:
        print(f"  ! Non-JSON response for {cmd} (first 200 bytes): {body[:200]!r}", file=sys.stderr)
        return None


def fetch_history_list(gid, page_size=PAGE_SIZE, max_pages=200, delay=0.4, keyword="", known_mids=None):
    all_rows = []
    skip = 0
    for _ in range(max_pages):
        print(f"  Fetching match list, skip={skip} ...")
        result = _request("history_list", {"skip": skip, "count": page_size, "keyword": keyword, "gid": gid})
        if result is None:
            break
        rows = result if isinstance(result, list) else result.get("list") or result.get("data") or []
        if not rows:
            break
        if known_mids:
            new_rows = []
            hit_known = False
            for r in rows:
                if extract_mid(r) in known_mids:
                    hit_known = True
                    break
                new_rows.append(r)
            all_rows.extend(new_rows)
            if hit_known:
                print(f"  Reached already-known match -- stopping early ({len(all_rows)} new).")
                break
        else:
            all_rows.extend(rows)
        if len(rows) < page_size:
            break
        skip += page_size
        time.sleep(delay)
    return all_rows


def extract_mid(row):
    for k in MID_KEYS:
        if k in row and row[k]:
            return row[k]
    return None


def summarize_list_row(row, my_name):
    p1_raw, p2_raw = row.get("p1name", ""), row.get("p2name", "")
    p1, p2 = normalize_name(p1_raw), normalize_name(p2_raw)
    my_name_norm = normalize_name(my_name)
    if my_name_norm and my_name_norm in p1:
        me_prefix, opp_prefix, opp_name = "p1", "p2", p2
    elif my_name_norm and my_name_norm in p2:
        me_prefix, opp_prefix, opp_name = "p2", "p1", p1
    else:
        me_prefix, opp_prefix, opp_name = None, None, None
    out = {
        "mid": row.get("mid"),
        "date": format_date(row.get("startTime")),
        "start_time": row.get("startTime"),
        "title": row.get("title"),
        "opponent": opp_name,
    }
    if me_prefix:
        out["my_legs"] = row.get(f"{me_prefix}winLegs")
        out["my_score"] = row.get(f"{me_prefix}allScore")
        out["my_darts"] = row.get(f"{me_prefix}allDarts")
        out["opp_legs"] = row.get(f"{opp_prefix}winLegs")
        out["opp_score"] = row.get(f"{opp_prefix}allScore")
        out["opp_darts"] = row.get(f"{opp_prefix}allDarts")
        if out["my_legs"] is not None and out["opp_legs"] is not None:
            out["result"] = "W" if out["my_legs"] > out["opp_legs"] else ("L" if out["my_legs"] < out["opp_legs"] else "D")
        if out["my_darts"]:
            out["my_three_dart_avg"] = round(out["my_score"] / out["my_darts"] * 3, 2)
    return out


def fetch_match_detail(mid, cache_dir=None):
    if cache_dir:
        cache_path = Path(cache_dir) / f"{mid}.json"
        if cache_path.exists():
            try:
                return json.loads(cache_path.read_text(encoding="utf-8")), True
            except (json.JSONDecodeError, OSError):
                pass
    detail = _request("history_match", {"mid": mid})
    if cache_dir and detail is not None:
        cache_path = Path(cache_dir) / f"{mid}.json"
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            cache_path.write_text(json.dumps(detail), encoding="utf-8")
        except OSError:
            pass
    return detail, False


def parse_match(detail, my_name=None):
    stats = detail.get("statsData", [])
    names = [normalize_name(p.get("name", f"player{i}")) for i, p in enumerate(stats)]
    tmid = detail.get("tmid", "")
    title = detail.get("title", detail.get("orgTitle", ""))
    mid = detail.get("mid", "")
    start_time = detail.get("startTime")
    start_score = detail.get("startScore", 501)

    match_row = {
        "mid": mid, "date": format_date(start_time), "tmid": tmid, "title": title,
        "start_time": start_time, "start_score": start_score, "match_type": detail.get("match_type", ""),
    }
    for i, p in enumerate(stats):
        prefix = f"p{i}_"
        match_row[prefix + "name"] = normalize_name(p.get("name", ""))
        match_row[prefix + "win_sets"] = p.get("winSets")
        match_row[prefix + "win_legs"] = p.get("winLegs")
        match_row[prefix + "all_score"] = p.get("allScore")
        match_row[prefix + "all_darts"] = p.get("allDarts")
        if p.get("allDarts"):
            match_row[prefix + "three_dart_avg"] = round(p.get("allScore", 0) / p.get("allDarts", 1) * 3, 2)

    my_name_norm_early = normalize_name(my_name) if my_name else None
    if my_name_norm_early and len(stats) >= 2:
        me_idx = next((i for i, n in enumerate(names) if n == my_name_norm_early), None)
        if me_idx is not None:
            opp_idx = 1 - me_idx if len(stats) == 2 else next((i for i in range(len(stats)) if i != me_idx), None)
            if opp_idx is not None:
                me_stats, opp_stats = stats[me_idx], stats[opp_idx]
                match_row["opponent"] = names[opp_idx]
                match_row["my_legs"] = me_stats.get("winLegs")
                match_row["opp_legs"] = opp_stats.get("winLegs")
                match_row["my_score"] = me_stats.get("allScore")
                match_row["my_darts"] = me_stats.get("allDarts")
                match_row["opp_score"] = opp_stats.get("allScore")
                match_row["opp_darts"] = opp_stats.get("allDarts")
                my_legs, opp_legs = match_row["my_legs"], match_row["opp_legs"]
                if my_legs is not None and opp_legs is not None:
                    match_row["result"] = "W" if my_legs > opp_legs else ("L" if my_legs < opp_legs else "D")
                if me_stats.get("allDarts"):
                    match_row["my_three_dart_avg"] = round(me_stats.get("allScore", 0) / me_stats.get("allDarts", 1) * 3, 2)

    leg_rows = []
    turn_rows = []

    for leg_idx, leg in enumerate(detail.get("legData", []), start=1):
        winner = leg.get("winner")
        player_data = leg.get("playerData", [])

        winner_had_checkout = False
        if winner is not None and 0 <= winner < len(player_data):
            for t in player_data[winner]:
                score = t.get("score")
                if isinstance(score, (int, float)) and score < 0:
                    winner_had_checkout = True
                    break

        if not winner_had_checkout:
            continue  # incomplete leg/walkover -- skip

        for pi, turns in enumerate(player_data):
            player_name = names[pi] if pi < len(names) else f"player{pi}"
            darts_used = None
            checkout_value = None
            checkout_attempts = 0

            if not turns:
                continue
            prev_lefts = []
            running_prev = turns[0].get("left")
            real_turns = turns[1:]
            for t in real_turns:
                prev_lefts.append(running_prev)
                running_prev = t.get("left")

            did_win = (pi == winner)

            # Checkout "attempts" -- a DART count using both where a
            # turn started AND where it ended (turn_checkout_credit),
            # not just a starting-score threshold. Real final checkout
            # turns use the actual, known dart count instead of an
            # estimate. Calibrated against real match data (48.1% exact
            # match rate, ~70% within 10%, 98.3% of nakka's combined
            # total across 216 matches) -- still an ESTIMATE, not a
            # reproduction of nakka's own (undisclosed) calculation.
            attempt_flags = [False] * len(real_turns)
            checkout_attempts = 0
            for i, t in enumerate(real_turns):
                pl = prev_lefts[i]
                if pl is None:
                    continue
                score = t.get("score")
                left = t.get("left")
                is_co_turn = isinstance(score, (int, float)) and score < 0
                if is_co_turn:
                    credit = abs(score)
                else:
                    credit = turn_checkout_credit(pl, left) if left is not None else 0
                if credit:
                    attempt_flags[i] = True
                    checkout_attempts += credit

            for ti, (t, prev_left, is_attempt) in enumerate(zip(real_turns, prev_lefts, attempt_flags), start=1):
                score = t.get("score")
                left = t.get("left")
                is_checkout_turn = isinstance(score, (int, float)) and score < 0
                turn_darts = abs(score) if is_checkout_turn else 3

                turn_rows.append({
                    "mid": mid, "leg": leg_idx, "player": player_name, "turn": ti,
                    "score": abs(score) if score is not None else None, "left": left,
                    "is_checkout": is_checkout_turn,
                    "is_checkout_attempt": is_attempt,
                    "checkout_darts": turn_darts if is_checkout_turn else None,
                    "checkout_value": prev_left if is_checkout_turn else None,
                })
                if is_checkout_turn:
                    darts_used = turn_darts
                    checkout_value = prev_left

            leg_rows.append({
                "mid": mid, "leg": leg_idx, "player": player_name, "won_leg": did_win,
                "start_score": start_score, "turns_taken": len(real_turns),
                "checkout_attempts": checkout_attempts,
                "checkout_darts": darts_used if did_win else None,
                "checkout_value": checkout_value if did_win else None,
            })

    def player_match_stats(player_name_norm):
        def turn_points(row):
            return row["checkout_value"] if row["is_checkout"] else row["score"]

        p_turns = [r for r in turn_rows if normalize_name(r["player"]) == player_name_norm]

        buckets = {"60": 0, "80": 0, "100": 0, "120": 0, "140": 0, "170": 0, "180s": 0}
        for r in p_turns:
            pts = turn_points(r)
            if pts is None:
                continue
            if pts == 180:
                buckets["180s"] += 1
            elif 170 <= pts <= 179:
                buckets["170"] += 1
            elif 140 <= pts <= 169:
                buckets["140"] += 1
            elif 120 <= pts <= 139:
                buckets["120"] += 1
            elif 100 <= pts <= 119:
                buckets["100"] += 1
            elif 80 <= pts <= 99:
                buckets["80"] += 1
            elif 60 <= pts <= 79:
                buckets["60"] += 1

        p_won_legs = [r for r in leg_rows if normalize_name(r["player"]) == player_name_norm and r["won_leg"]]
        p_all_legs = [r for r in leg_rows if normalize_name(r["player"]) == player_name_norm]
        total_attempts = sum(r["checkout_attempts"] for r in p_all_legs if r["checkout_attempts"] is not None)
        total_makes = len(p_won_legs)
        checkout_pct = round(total_makes / total_attempts * 100, 1) if total_attempts else None
        checkout_values = [r["checkout_value"] for r in p_won_legs if r["checkout_value"] is not None]
        high_finish = max(checkout_values) if checkout_values else None
        hundred_plus_finishes = sum(1 for v in checkout_values if v >= 100)

        leg_darts = []
        for r in p_won_legs:
            if r["checkout_darts"] is not None:
                leg_darts.append((r["turns_taken"] - 1) * 3 + r["checkout_darts"])
        best_leg_darts = min(leg_darts) if leg_darts else None
        worst_leg_darts = max(leg_darts) if leg_darts else None

        first9_avgs = []
        for leg_idx in sorted({r["leg"] for r in p_turns}):
            leg_turns = sorted((r for r in p_turns if r["leg"] == leg_idx), key=lambda r: r["turn"])[:3]
            if not leg_turns:
                continue
            pts_sum = sum(turn_points(r) or 0 for r in leg_turns)
            darts_sum = sum((r["checkout_darts"] if r["is_checkout"] else 3) for r in leg_turns)
            if darts_sum:
                first9_avgs.append(pts_sum / darts_sum * 3)
        first9_avg = round(sum(first9_avgs) / len(first9_avgs), 2) if first9_avgs else None

        return {
            "60_plus": buckets["60"], "80_plus": buckets["80"], "100_plus": buckets["100"],
            "120_plus": buckets["120"], "140_plus": buckets["140"], "170_plus": buckets["170"],
            "180s": buckets["180s"], "high_finish": high_finish, "100_plus_finishes": hundred_plus_finishes,
            "best_leg_darts": best_leg_darts, "worst_leg_darts": worst_leg_darts,
            "first9_avg": first9_avg, "checkout_attempts_total": total_attempts,
            "checkout_makes": total_makes, "checkout_pct": checkout_pct,
        }

    my_name_norm = normalize_name(my_name) if my_name else None
    if my_name_norm:
        for k, v in player_match_stats(my_name_norm).items():
            match_row[f"my_{k}"] = v
        opp_name_norm = next((n for n in names if n != my_name_norm), None)
        if opp_name_norm:
            for k, v in player_match_stats(opp_name_norm).items():
                match_row[f"opp_{k}"] = v

    return match_row, leg_rows, turn_rows


def load_existing_matches(out_dir):
    path = Path(out_dir) / "matches.csv"
    if not path.exists():
        return {}
    with open(path, newline="", encoding="utf-8") as f:
        return {r["mid"]: r for r in csv.DictReader(f) if r.get("mid")}


def load_existing_rows(path):
    path = Path(path)
    if not path.exists():
        return []
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    if not rows:
        return
    fieldnames = []
    for r in rows:
        for k in r.keys():
            if k not in fieldnames:
                fieldnames.append(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)
    print(f"  wrote {len(rows)} rows -> {path}")


def _write_matches_csv(out_dir, new_rows, existing_matches):
    if existing_matches:
        combined = list(existing_matches.values())
        seen = set(existing_matches.keys())
        for r in new_rows:
            if r["mid"] not in seen:
                combined.append(r)
                seen.add(r["mid"])
        combined.sort(key=lambda r: int(r["start_time"] or 0), reverse=True)
        write_csv(Path(out_dir) / "matches.csv", combined)
    else:
        write_csv(Path(out_dir) / "matches.csv", new_rows)


# =====================================================================
# OCHE export (was export_to_oche.py)
# =====================================================================

DATA_HEADER = [
    "Mid", "Date", "Opponent", "Event", "Legs_You", "Legs_Opp",
    "Your_3Dart_Avg", "Your_First9", "Your_Checkout%",
    "Your_High_Finish", "Your_Checkout_Makes", "Your_Checkout_Attempts",
    "Your_60_Plus", "Your_80_Plus", "Your_100_Plus", "Your_120_Plus",
    "Your_140_Plus", "Your_170_Plus", "Your_180s",
    "Your_100_Plus_Finishes", "Your_Best_Leg_Darts", "Your_Worst_Leg_Darts",
    "Opp_3Dart_Avg", "Opp_First9", "Opp_Checkout%",
    "Opp_High_Finish", "Opp_Checkout_Makes", "Opp_Checkout_Attempts",
    "Opp_60_Plus", "Opp_80_Plus", "Opp_100_Plus", "Opp_120_Plus",
    "Opp_140_Plus", "Opp_170_Plus", "Opp_180s",
    "Opp_100_Plus_Finishes", "Opp_Best_Leg_Darts", "Opp_Worst_Leg_Darts",
]

LEGS_HEADER = [
    "Mid", "Date", "Opponent", "Event", "Leg", "Player", "Won",
    "Darts", "CheckoutValue", "StartScore",
]

_STAGE_RE = re.compile(
    r"\s+(Group\s+\d+|Top\s+\d+|Last\s+\d+|Round\s+\d+|R\d+|"
    r"Semi-?\s?final|Quarter-?\s?final|Final)$",
    re.IGNORECASE,
)


def normalize_event(title):
    if not title:
        return title
    return _STAGE_RE.sub("", title).strip()


def convert_match_row(row):
    date = (row.get("date") or "").split(" ")[0]
    opp_avg = ""
    try:
        opp_score = float(row.get("opp_score") or 0)
        opp_darts = float(row.get("opp_darts") or 0)
        if opp_darts:
            opp_avg = round(opp_score / opp_darts * 3, 2)
    except (ValueError, TypeError):
        pass
    return {
        "Mid": row.get("mid", ""), "Date": date, "Opponent": row.get("opponent", ""),
        "Event": normalize_event(row.get("title", "")),
        "Legs_You": row.get("my_legs", ""), "Legs_Opp": row.get("opp_legs", ""),
        "Your_3Dart_Avg": row.get("my_three_dart_avg", ""),
        "Your_First9": row.get("my_first9_avg", ""),
        "Your_Checkout%": row.get("my_checkout_pct", ""),
        "Your_High_Finish": row.get("my_high_finish", ""),
        "Your_Checkout_Makes": row.get("my_checkout_makes", ""),
        "Your_Checkout_Attempts": row.get("my_checkout_attempts_total", ""),
        "Your_60_Plus": row.get("my_60_plus", ""), "Your_80_Plus": row.get("my_80_plus", ""),
        "Your_100_Plus": row.get("my_100_plus", ""), "Your_120_Plus": row.get("my_120_plus", ""),
        "Your_140_Plus": row.get("my_140_plus", ""), "Your_170_Plus": row.get("my_170_plus", ""),
        "Your_180s": row.get("my_180s", ""),
        "Your_100_Plus_Finishes": row.get("my_100_plus_finishes", ""),
        "Your_Best_Leg_Darts": row.get("my_best_leg_darts", ""),
        "Your_Worst_Leg_Darts": row.get("my_worst_leg_darts", ""),
        "Opp_3Dart_Avg": opp_avg, "Opp_First9": row.get("opp_first9_avg", ""),
        "Opp_Checkout%": row.get("opp_checkout_pct", ""),
        "Opp_High_Finish": row.get("opp_high_finish", ""),
        "Opp_Checkout_Makes": row.get("opp_checkout_makes", ""),
        "Opp_Checkout_Attempts": row.get("opp_checkout_attempts_total", ""),
        "Opp_60_Plus": row.get("opp_60_plus", ""), "Opp_80_Plus": row.get("opp_80_plus", ""),
        "Opp_100_Plus": row.get("opp_100_plus", ""), "Opp_120_Plus": row.get("opp_120_plus", ""),
        "Opp_140_Plus": row.get("opp_140_plus", ""), "Opp_170_Plus": row.get("opp_170_plus", ""),
        "Opp_180s": row.get("opp_180s", ""),
        "Opp_100_Plus_Finishes": row.get("opp_100_plus_finishes", ""),
        "Opp_Best_Leg_Darts": row.get("opp_best_leg_darts", ""),
        "Opp_Worst_Leg_Darts": row.get("opp_worst_leg_darts", ""),
    }


def _total_darts(leg_row):
    try:
        turns_taken = int(leg_row.get("turns_taken") or 0)
        checkout_darts = leg_row.get("checkout_darts")
        if checkout_darts in (None, ""):
            return ""
        return (turns_taken - 1) * 3 + int(checkout_darts)
    except (ValueError, TypeError):
        return ""


def convert_legs(leg_rows, matches_by_mid, my_name_norm):
    out = []
    for r in leg_rows:
        mid = r.get("mid")
        match = matches_by_mid.get(mid)
        if not match:
            continue
        is_me = normalize_name(r.get("player")) == my_name_norm
        won = str(r.get("won_leg")).strip().lower() in ("true", "1", "yes")
        out.append({
            "Mid": mid, "Date": (match.get("date") or "").split(" ")[0],
            "Opponent": match.get("opponent", ""), "Event": normalize_event(match.get("title", "")),
            "Leg": r.get("leg", ""), "Player": "You" if is_me else "Opponent",
            "Won": "1" if won else "0", "Darts": _total_darts(r),
            "CheckoutValue": r.get("checkout_value", "") or "",
            "StartScore": r.get("start_score", "") or "",
        })
    return out


def filter_by_start_score(match_rows, start_score):
    """
    Keeps only matches starting from the given score (default 501, the
    standard game) -- e.g. excludes 301 tournaments so they don't skew
    "progress over time" stats built from mixed game lengths. Matches
    missing a start_score entirely (e.g. pulled with --summary-only, or
    from before this field existed) are DROPPED, not assumed 501 -- safer
    to leave them out than silently mix in an unknown game type.
    Pass start_score='all' to disable filtering entirely.
    """
    if str(start_score).lower() == "all":
        return match_rows, 0
    target = str(start_score)
    kept = [r for r in match_rows if str(r.get("start_score") or "").strip() == target]
    dropped = len(match_rows) - len(kept)
    return kept, dropped


def load_excluded_mids(path):
    """
    Reads a plain text file of match ids to exclude from OCHE stats, one
    per line. Blank lines and lines starting with # are ignored, and
    anything after a # on a line is a trailing comment (leave yourself a
    note about why), e.g.:
        m1a2b3c4_1234567890  # weird one-off practice game
    Returns an empty set if the file doesn't exist -- this is optional
    and hand-maintained, not something every user needs to touch.
    """
    path = Path(path)
    if not path.exists():
        return set()
    mids = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip()
        if line:
            mids.add(line)
    return mids


def filter_by_exclusion(match_rows, excluded_mids):
    if not excluded_mids:
        return match_rows, 0
    kept = [r for r in match_rows if r.get("mid") not in excluded_mids]
    dropped = len(match_rows) - len(kept)
    return kept, dropped


def export_to_oche(matches_rows, legs_rows, my_name, out_dir, start_score="501", excluded_mids=None):
    """Writes data.csv + legs.csv (OCHE-ready) into out_dir. Returns (data_rows, legs_rows_out)."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    matches_rows, dropped = filter_by_start_score(matches_rows, start_score)
    if dropped:
        print(f"  (excluded {dropped} non-{start_score} match(es) from your OCHE stats -- "
              f"e.g. a 301 tournament -- your raw pulled data still has everything)")

    matches_rows, excl_dropped = filter_by_exclusion(matches_rows, excluded_mids or set())
    if excl_dropped:
        print(f"  (excluded {excl_dropped} match(es) listed in excluded_match_ids.txt)")

    data_rows = [convert_match_row(r) for r in matches_rows]
    required = ["Date", "Opponent", "Legs_You", "Legs_Opp"]
    bad_rows = [r for r in data_rows if any(not r[k] for k in required)]
    if bad_rows:
        print(f"  WARNING: {len(bad_rows)} of {len(data_rows)} matches are missing a required field "
              f"and OCHE will silently drop them.")
    data_rows.sort(key=lambda r: r["Date"])
    with open(out_dir / "data.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=DATA_HEADER)
        w.writeheader()
        w.writerows(data_rows)

    matches_by_mid = {r["mid"]: r for r in matches_rows if r.get("mid")}
    my_name_norm = normalize_name(my_name)
    legs_out = convert_legs(legs_rows, matches_by_mid, my_name_norm)
    legs_out.sort(key=lambda r: (r["Date"], r["Mid"], r["Leg"]))
    with open(out_dir / "legs.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=LEGS_HEADER)
        w.writeheader()
        w.writerows(legs_out)

    return data_rows, legs_out


# =====================================================================
# Folder / config helpers (new -- this is what makes the friend-facing
# workflow simple: one fixed, predictable folder, remembered settings)
# =====================================================================

def default_data_dir():
    home = Path.home()
    docs = home / "Documents"
    if docs.exists():
        return docs / "Oche"
    return home / "Oche"


def load_config(out_dir):
    path = Path(out_dir) / "config.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def save_config(out_dir, gid, my_name):
    path = Path(out_dir) / "config.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"gid": gid, "my_name": my_name}, indent=2), encoding="utf-8")


def prompt_for_config():
    print()
    print("First time setup -- just two questions, and you won't be asked again.")
    print()
    try:
        my_name = input("Your exact display name as it appears on n01: ").strip()
        gid = input("Your n01darts gid (see the docstring at the top of this file for how to find it): ").strip()
    except EOFError:
        my_name, gid = "", ""
    return gid, my_name


# =====================================================================
# Main
# =====================================================================

def main():
    ap = argparse.ArgumentParser(description="Pull your n01darts.com history and produce OCHE-ready files.")
    ap.add_argument("--out-dir", default=None, help="Data folder (default: Documents/Oche in your home folder)")
    ap.add_argument("--gid", help="Your n01darts gid (skips the saved-config lookup)")
    ap.add_argument("--my-name", help="Your exact n01 display name (skips the saved-config lookup)")
    ap.add_argument("--reconfigure", action="store_true", help="Forget the saved gid/name and ask again")
    ap.add_argument("--full", action="store_true", help="Force a complete re-pull, ignoring anything already saved")
    ap.add_argument("--from-cache", action="store_true", help="Reprocess your whole history from the local cache -- zero requests to n01's server")
    ap.add_argument("--summary-only", action="store_true", help="Only pull match summaries, skip leg/turn detail (faster, less data)")
    ap.add_argument("--delay", type=float, default=0.5, help="Seconds between per-match requests (politeness delay)")
    ap.add_argument("--mids-file", help="Advanced: skip history_list, use a plain text file of mids instead")
    ap.add_argument("--start-score", default="501", help="Only include matches starting from this score in your OCHE stats (default: 501, the standard game). Pass 'all' to include every game type (e.g. 301 tournaments).")
    args = ap.parse_args()

    base_dir = Path(args.out_dir) if args.out_dir else default_data_dir()
    raw_dir = base_dir / "raw_pull"
    oche_dir = base_dir / "oche_data"
    cache_dir = raw_dir / "raw_cache"
    raw_dir.mkdir(parents=True, exist_ok=True)

    print(f"Data folder: {base_dir}")

    # ---- gid/name resolution: CLI overrides > saved config > prompt ----
    config = None if args.reconfigure else load_config(base_dir)
    gid = args.gid or (config or {}).get("gid")
    my_name = args.my_name or (config or {}).get("my_name")

    if not gid or not my_name:
        new_gid, new_name = prompt_for_config()
        gid = gid or new_gid
        my_name = my_name or new_name
        if not gid or not my_name:
            print("Need both your gid and your display name to continue.", file=sys.stderr)
            sys.exit(1)
        save_config(base_dir, gid, my_name)
        print(f"Saved -- you won't be asked again (see {base_dir / 'config.json'}).")
    elif config is None and (args.gid or args.my_name):
        # first run, but gid/name came from CLI flags rather than a prompt -- save them too
        save_config(base_dir, gid, my_name)

    # ---- from-cache: reprocess everything locally, zero network calls ----
    if args.from_cache:
        if not cache_dir.exists():
            print(f"No cache found at {cache_dir} -- run a normal pull first.", file=sys.stderr)
            sys.exit(1)
        mids = sorted(p.stem for p in cache_dir.glob("*.json"))
        if not mids:
            print(f"Cache at {cache_dir} is empty -- nothing to reprocess.", file=sys.stderr)
            sys.exit(1)
        print(f"Reprocessing {len(mids)} matches from local cache -- 0 requests to n01's server.")
        list_rows = []
        existing_matches = {}
    else:
        existing_matches = {} if args.full else load_existing_matches(raw_dir)
        if existing_matches:
            print(f"Found {len(existing_matches)} matches already saved -- updating incrementally.")
        elif args.full:
            print("--full given -- doing a complete re-pull.")
        else:
            print("No existing data found -- doing a full pull (this can take a few minutes).")

        list_rows = []
        mids = []
        if args.mids_file:
            mids = [l.strip() for l in Path(args.mids_file).read_text().splitlines() if l.strip()]
        else:
            known_mids = set(existing_matches.keys()) if existing_matches else None
            list_rows = fetch_history_list(gid, known_mids=known_mids)
            print(f"  got {len(list_rows)} new match(es)")
            mids = [extract_mid(r) for r in list_rows if extract_mid(r)]
            if not mids and existing_matches:
                print("No new matches since last pull.")
                _regenerate_oche_export(base_dir, raw_dir, oche_dir, my_name, start_score=args.start_score)
                has_local = generate_local_index(base_dir, my_name)
                _finish(base_dir, oche_dir, has_local)
                return

    new_summary_rows = [summarize_list_row(r, my_name=my_name) for r in list_rows] if list_rows else []

    if args.summary_only:
        if new_summary_rows:
            _write_matches_csv(raw_dir, new_summary_rows, existing_matches)
        _regenerate_oche_export(base_dir, raw_dir, oche_dir, my_name, start_score=args.start_score)
        has_local = generate_local_index(base_dir, my_name)
        _finish(base_dir, oche_dir, has_local)
        return

    print(f"Fetching leg/turn detail for {len(mids)} match(es) ...")
    match_rows, leg_rows, turn_rows = [], [], []
    cache_hits = 0
    for i, mid in enumerate(mids, start=1):
        detail, was_cached = fetch_match_detail(mid, cache_dir=cache_dir)
        if was_cached:
            cache_hits += 1
        if not detail:
            continue
        m, l, t = parse_match(detail, my_name=my_name)
        match_rows.append(m)
        leg_rows.extend(l)
        turn_rows.extend(t)
        if i % 25 == 0 or i == len(mids):
            print(f"  {i}/{len(mids)} done" + (f" ({cache_hits} from cache)" if cache_hits else ""))
        if not was_cached:
            time.sleep(args.delay)

    if new_summary_rows:
        extra_by_mid = {m["mid"]: m for m in match_rows}
        extra_keys = [
            "start_score",
            "my_60_plus", "my_80_plus", "my_100_plus", "my_120_plus", "my_140_plus", "my_170_plus", "my_180s",
            "my_high_finish", "my_100_plus_finishes", "my_best_leg_darts", "my_worst_leg_darts", "my_first9_avg",
            "my_checkout_attempts_total", "my_checkout_makes", "my_checkout_pct",
            "opp_60_plus", "opp_80_plus", "opp_100_plus", "opp_120_plus", "opp_140_plus", "opp_170_plus", "opp_180s",
            "opp_high_finish", "opp_100_plus_finishes", "opp_best_leg_darts", "opp_worst_leg_darts", "opp_first9_avg",
            "opp_checkout_attempts_total", "opp_checkout_makes", "opp_checkout_pct",
        ]
        for row in new_summary_rows:
            extra = extra_by_mid.get(row["mid"])
            if extra:
                for k in extra_keys:
                    if k in extra:
                        row[k] = extra[k]
        _write_matches_csv(raw_dir, new_summary_rows, existing_matches)
    elif match_rows:
        _write_matches_csv(raw_dir, match_rows, existing_matches)

    if existing_matches:
        existing_legs = load_existing_rows(raw_dir / "legs.csv")
        existing_turns = load_existing_rows(raw_dir / "turns.csv")
        write_csv(raw_dir / "legs.csv", existing_legs + leg_rows)
        write_csv(raw_dir / "turns.csv", existing_turns + turn_rows)
    else:
        write_csv(raw_dir / "legs.csv", leg_rows)
        write_csv(raw_dir / "turns.csv", turn_rows)

    _regenerate_oche_export(base_dir, raw_dir, oche_dir, my_name, start_score=args.start_score)
    has_local = generate_local_index(base_dir, my_name)
    _finish(base_dir, oche_dir, has_local)


def _regenerate_oche_export(base_dir, raw_dir, oche_dir, my_name, start_score="501"):
    matches_path = raw_dir / "matches.csv"
    legs_path = raw_dir / "legs.csv"
    if not matches_path.exists():
        return
    with open(matches_path, newline="", encoding="utf-8") as f:
        matches_rows = list(csv.DictReader(f))
    legs_rows = load_existing_rows(legs_path)
    excluded_mids = load_excluded_mids(Path(base_dir) / "excluded_match_ids.txt")
    print("Preparing your OCHE files ...")
    export_to_oche(matches_rows, legs_rows, my_name, oche_dir, start_score=start_score, excluded_mids=excluded_mids)


def _js_string_escape(text):
    """Escape text for safe embedding inside a JS template literal (backtick string)."""
    return text.replace("\\", "\\\\").replace("`", "\\`").replace("${", "\\${")


def generate_local_index(base_dir, my_name):
    """
    Bakes the person's actual data.csv/legs.csv content directly into a
    personalized copy of index.html, saved at base_dir/index.html. This
    relies on OCHE's own EMBEDDED_CSV/LEGS_EMBEDDED fallback (meant for
    exactly this: opened via file://, where fetch() can't load sibling
    files) so the result is genuinely double-click-and-done, no server,
    no upload step, no internet needed after this script has already run.

    Returns True if a template was found and a personalized copy was
    written, False if no template is available (script run standalone,
    without oche_template.html alongside it -- not fatal, just skipped).
    """
    template_path = Path(__file__).resolve().parent / "oche_template.html"
    if not template_path.exists():
        return False

    data_path = Path(base_dir) / "oche_data" / "data.csv"
    legs_path = Path(base_dir) / "oche_data" / "legs.csv"
    if not data_path.exists():
        return False

    template = template_path.read_text(encoding="utf-8")
    data_csv = data_path.read_text(encoding="utf-8")
    legs_csv = legs_path.read_text(encoding="utf-8") if legs_path.exists() else ""

    out_html = template
    out_html = out_html.replace(
        'const OWNER_NAME = "Craig";',
        f'const OWNER_NAME = "{my_name}";',
    )
    out_html = out_html.replace(
        "const EMBEDDED_CSV = ``; // optional offline fallback (normally empty)",
        f"const EMBEDDED_CSV = `{_js_string_escape(data_csv)}`;",
    )
    out_html = out_html.replace(
        "const LEGS_EMBEDDED = ``; // optional offline fallback for legs.csv (normally empty)",
        f"const LEGS_EMBEDDED = `{_js_string_escape(legs_csv)}`;",
    )

    out_path = Path(base_dir) / "index.html"
    out_path.write_text(out_html, encoding="utf-8")
    return True


def _finish(base_dir, oche_dir, has_local):
    print()
    print("=" * 60)
    if has_local:
        print("Done! Your personal stats page is ready:")
        print(f"  {Path(base_dir) / 'index.html'}")
        print()
        print("Just double-click it -- your data is baked right in, no")
        print("internet needed, no upload step.")
        print()
        print("(If you'd also like to add your data to oche.pages.dev,")
        print(f"the files for that are at {oche_dir} -- click")
        print('"Analyze your own data" there and select both.)')
    else:
        print("Done! Your files are ready at:")
        print(f"  {oche_dir / 'data.csv'}")
        print(f"  {oche_dir / 'legs.csv'}")
        print()
        print("Go to oche.pages.dev, click \"Analyze your own data\", and")
        print("select (or drag in) both files.")
    print("=" * 60)
    try:
        input("\nPress Enter to close...")
    except EOFError:
        pass


if __name__ == "__main__":
    main()
